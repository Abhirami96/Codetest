package com.example.item.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.item.entity.ItemEntity;
import com.example.item.service.ItemService;

@RestController
public class ItemController {
	@Autowired
	ItemService itemservice;
	
	@PostMapping("/additem")
	public String addItem(@RequestBody ItemEntity it) {
		itemservice.addItem(it);
		return "added Item";
	}
	
	@GetMapping("/getallitems")
	public List allItems() {
		return itemservice.getAllItem();
	}
	
	
}
