package com.example.item.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.item.entity.ItemEntity;
import com.example.item.repo.ItemRepo;

@Service
public class ItemService {

	@Autowired
	ItemRepo itemrepo;

	public void addItem(ItemEntity i) {
		itemrepo.save(i);
	}

	public List getAllItem() {
		List<ItemEntity> list = new ArrayList<ItemEntity>();
		itemrepo.findAll().forEach(data -> list.add(data));

		Collections.sort(list, ItemService.ItemPrice);

		return list;
	}

	// Comparator for sorting the list by roll no
	public static Comparator<ItemEntity> ItemPrice = new Comparator<ItemEntity>() {

		// Method
		public int compare(ItemEntity s1, ItemEntity s2) {

			double item1 = s1.getItemPrice();
			double item2 = s2.getItemPrice();
			
			return (int) (item2 - item1);
		}
	};
}
