package com.example.item.repo;
import org.springframework.data.repository.CrudRepository;

import com.example.item.entity.ItemEntity;

public interface ItemRepo extends CrudRepository<ItemEntity,Integer>{

}
