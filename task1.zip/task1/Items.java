package com.test.brands;

class Items
{
    String ItemsId;
    String ShortDescription;
    String Brand;
    int Price;
    
  
 //To hold Items
    public Items(String ItemsId, String ShortDescription, int d, String Brand )
    {
        this.ItemsId = ItemsId;
        this.ShortDescription = ShortDescription;
        this.Brand = Brand;
        this.Price = d;
    }


	
}
