package com.test.brands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class GenerateReport {
	
	
	
	public static void main (String args[])
	{
	
		
		
		
		   ArrayList<Items> ar = new ArrayList<Items>();
		   
		   
	        ar.add(new Items("Item-1", "Prod-1", 33, "Double Horse"));
	        ar.add(new Items("Item-2", "Prod-2", 64, "TBI"));
	        ar.add(new Items("Item-3", "Prod-3", 54, "Parle"));
	        ar.add(new Items("Item-4", "Prod-4", 76, "THS"));
	        ar.add(new Items("Item-5", "Prod-5", 22, "Britannia"));
	        ar.add(new Items("Item-6", "Prod-6", 102, "MariGold"));
	        ar.add(new Items("Item-7", "Prod-7", 98, "TUG"));
	        ar.add(new Items("Item-8", "Prod-8", 44, "TRW"));
	        ar.add(new Items("Item-9", "Prod-9", 99, "TAA"));
	        ar.add(new Items("Item-10", "Prod-10", 176, "TCF"));
	  
	     
	        
	      //  System.out.println(ar.stream().filter(x->x.Brand.startsWith("T")).collect(Collectors.toList()));
	        
	        List<Items> result =ar.stream().filter(x->x.Brand.startsWith("T")).collect(Collectors.toList());
		//System.out.println(result);
	  
	        Collections.sort(result, new ItemsComparator());
	  
	        System.out.println("Sorted Values are:\r\n");
	        for (int i=0; i<result.size(); i++)
	            System.out.println(result.get(i).ItemsId + "    "+result.get(i).ShortDescription+ "    "+result.get(i).Price+ "    "+result.get(i).Brand);
	    }
        
        
	

	

}
