package com.test.brands;

import java.util.Comparator;

public class ItemsComparator implements Comparator<Items>{

	 public int compare(Items a, Items b)
	    {
	        return  b.Price-a.Price;
	    }
}
